#!/bin/bash

# If Qt module is PySide
pyside-rcc -o Resources_pyside.py Resources.qrc

