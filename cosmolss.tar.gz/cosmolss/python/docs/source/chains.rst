getdist.chains
==================================


.. automodule:: getdist.chains
   :members:
   