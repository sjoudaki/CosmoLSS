getdist.paramnames
==================================



.. automodule:: getdist.paramnames
   :members:




   